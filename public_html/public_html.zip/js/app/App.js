/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


//wczytaj mape
//dodaj wiezyczki do managera
//dodaj przeciwnikow na mape


//petla gry
//sprawdz wiezyczki czy moga strzelac
//porusz pociskami
//porusz przeciwnikami
//wykasuj przeciwnikow z 0 hp.
//wykasuj pociski ktore trafily
//
//
//rysuj mape
